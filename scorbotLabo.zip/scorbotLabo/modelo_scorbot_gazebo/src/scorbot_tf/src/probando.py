
import math
import numpy as np
import rospy
from std_msgs.msg import Float64
import roslib 
from control_msgs.msg import JointControllerState
from geometry_msgs.msg import Point  

                                                        
        
#include <functional>
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/common.hh>
#include <ignition/math/Vector3.hh>

namespace gazebo
{
  class ModelPush : public ModelPlugin
  {
    public: void Load(physics::ModelPtr _parent, sdf::ElementPtr /*_sdf*/)
    {
      // Store the pointer to the model
      this->model = _parent;

      // Listen to the update event. This event is broadcast every
      // simulation iteration.
      this->updateConnection = event::Events::ConnectWorldUpdateBegin(
          std::bind(&ModelPush::OnUpdate, this));
    }

    // Called by the world update start event
    public: void OnUpdate()
    {
      // Apply a small linear velocity to the model.
      this->model->SetLinearVel(ignition::math::Vector3d(.3, 0, 0));
    }

    // Pointer to the model
    private: physics::ModelPtr model;

    // Pointer to the update event connection
    private: event::ConnectionPtr updateConnection;
  };

  // Register this plugin with the simulator
  GZ_REGISTER_MODEL_PLUGIN(ModelPush)
}   
        
        
        
        
        
        
        
        
        
    
#     <model name='joint_velocity_demo'>
#     <plugin name='set_joint_velocity_plugin' filename='libSetJointVelocityPlugin.so'/>



def obtenerVelAc (ainicial,afinal,t):
#interpolador de tercer orden
    vec_posvel = [[ainicial], [0], [afinal], [0]] #posicion inicial, velocidad inicial, posicion final, velocidad final. vectorvertical
    matriztiempos = [[1, 0, 0, 0],[0, 1, 0, 0],[1, t, t*t, t*t*t], [0, 1, 2*t, 3*t*t]]
    coefs_salida = np.linalg.solve(matriztiempos, vec_posvel)
    return coefs_salida


def divisionRecorrido(ainicial, afinal, t, coefs, intervaloentrepos):
    #quiero cada "intervaloentrepos" segundos guardar el angulo en el que esta segun mis ecuaciones la articulacion
    pos_medio_segundo = []
    pos_medio_segundo.append(ainicial)
    tposaobtener = intervaloentrepos
    x0 = ainicial
    while (x0 != afinal and tposaobtener != t ): # mientras que no llegue al final
        x = coefs[0] + coefs[1]*tposaobtener + coefs[2]*tposaobtener*tposaobtener + coefs[3]*tposaobtener*tposaobtener*tposaobtener
        pos_medio_segundo.append(float(x))
        x0 = x
        tposaobtener = tposaobtener + intervaloentrepos
        
    pos_medio_segundo.append(afinal)
    return pos_medio_segundo


#devuelve una lista con 5 sublistas (1 por articulacion) donde se detalla el angulo en el que tiene que estar cada 'intervaloentrepos' segundos y una lista con 5 sublistas con las velocidades
def multiplesarticulaciones(angulosiniciales, angulosfinales, tiempo_de_recorrido, intervalos):
    posiciones_por_joint = []
    velocidades_por_joint = []
    for i in range (0,5):
        ainicial = angulosiniciales [i]
        afinal = angulosfinales [i]
        t = tiempo_de_recorrido
        coefs = obtenerVelAc(ainicial, afinal, t)
        intervaloentrepos = intervalos [i]
        posiciones_joint_i = divisionRecorrido(ainicial, afinal, t, coefs, intervaloentrepos) 
        posiciones_por_joint.append(posiciones_joint_i)
        velocidades_joint_i = []
        for j in range(0,len(posiciones_joint_i)):
            if j == 0:
                velocidad = coefs[1]
                velocidades_joint_i.append(velocidad)
            else: 
                velocidad = coefs[1] + coefs[2]*2*intervaloentrepos + coefs[3]*3*intervaloentrepos*intervaloentrepos
                velocidades_joint_i.append(velocidad)
        velocidades_por_joint.append(velocidades_joint_i)
    return posiciones_por_joint, velocidades_joint_i





def setearUnaVel(numerodearticulacion):
    intervaloactual = 0
    while intervaloactual < len(posvel[numerodearticulacion]): #mientras no haya terminado el recorrido
        rospy.sleep(intervalos[numerodearticulacion])
        this->model->GetJoint(joints[numerodearticulacion])-> SetVelocity(1 , posvel[1][numerodearticulacion][i]) #siesqueeslacoordenadatheta
        intervaloactual = intervaloactual + 1


def todasLasVel():
    for i in range(0,5):
        setearUnaVel(i)






joints = ["base", "shoulder", "elbow", "pitch", "roll"]
angulosiniciales = []
angulosfinales = []
tiempo_de_recorrido = -1 #por si algo anda mal
intervalos = []

if __name__ == '__main__':

    try:     
        for i in range(0, 5):
            e = float(input('ingrese angulos iniciales ordenadamente: '))
            # adding the element
            angulosiniciales.append(e)  
        for i in range (0, 5):
            e = float(input('ingrese angulos finales ordenadamente: '))
            # adding the element
            angulosfinales.append(e)
        e = float(input('ingrese tiempo (s): '))
        tiempo_de_recorrido = e
        for i in range(0,5):
            e = float(input('ingrese intervalo de tiempo entre posiciones de un mismo angulo, ordenadamente'))
            intervalos.append(e)
            
        posvel = multiplesarticulaciones(angulosiniciales, angulosfinales, tiempo_de_recorrido, intervalos)
        todasLasVel()
            
        
    except rospy.ROSInterruptException:
        pass

